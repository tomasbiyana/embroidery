import { Link } from 'react-router-dom';
import { Instagram, Facebook, Twitter, MessageCircle, Mail, Phone, MapPin } from 'lucide-react';

export default function Footer() {
  const socialLinks = [
    { icon: Instagram, label: 'Instagram', href: 'https://instagram.com/stitchandstyle' },
    { icon: Facebook, label: 'Facebook', href: 'https://facebook.com/stitchandstyle' },
    { icon: Twitter, label: 'Twitter', href: 'https://twitter.com/stitchandstyle' },
    { icon: MessageCircle, label: 'WhatsApp', href: 'https://wa.me/1234567890' },
  ];

  const quickLinks = [
    { label: 'Home', href: '/' },
    { label: 'Products', href: '/#products' },
    { label: 'About Us', href: '/#about' },
    { label: 'Contact', href: '/#contact' },
    { label: 'FAQ', href: '/#faq' },
  ];

  const userLinks = [
    { label: 'Login', href: '/login' },
    { label: 'Register', href: '/register' },
    { label: 'Seller Dashboard', href: '/seller/dashboard' },
    { label: 'My Orders', href: '/buyer/dashboard' },
  ];

  return (
    <footer className="bg-[#2d2a26] text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand Section */}
          <div>
            <h3 className="text-2xl font-serif text-[#c9a87c] mb-4">Stitch & Style</h3>
            <p className="text-stone-300 text-sm mb-6">
              Handcrafted embroidery and handmade items. Each piece tells a story of tradition, craftsmanship, and love.
            </p>
            <div className="flex space-x-4">
              {socialLinks.map((link) => (
                <a
                  key={link.label}
                  href={link.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-[#8b6d4b] transition-colors"
                  aria-label={link.label}
                >
                  <link.icon className="w-5 h-5" />
                </a>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold mb-4 text-[#c9a87c]">Quick Links</h4>
            <ul className="space-y-2">
              {quickLinks.map((link) => (
                <li key={link.label}>
                  <Link
                    to={link.href}
                    className="text-stone-300 hover:text-white transition-colors text-sm"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* User Links */}
          <div>
            <h4 className="text-lg font-semibold mb-4 text-[#c9a87c]">For Users</h4>
            <ul className="space-y-2">
              {userLinks.map((link) => (
                <li key={link.label}>
                  <Link
                    to={link.href}
                    className="text-stone-300 hover:text-white transition-colors text-sm"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-lg font-semibold mb-4 text-[#c9a87c]">Contact Us</h4>
            <ul className="space-y-3">
              <li className="flex items-start space-x-3">
                <MapPin className="w-5 h-5 text-[#8b6d4b] flex-shrink-0 mt-0.5" />
                <span className="text-stone-300 text-sm">
                  123 Craft Street, Artisan District<br />
                  Creative City, CC 12345
                </span>
              </li>
              <li className="flex items-center space-x-3">
                <Phone className="w-5 h-5 text-[#8b6d4b] flex-shrink-0" />
                <span className="text-stone-300 text-sm">+1 (234) 567-8900</span>
              </li>
              <li className="flex items-center space-x-3">
                <Mail className="w-5 h-5 text-[#8b6d4b] flex-shrink-0" />
                <span className="text-stone-300 text-sm">hello@stitchandstyle.com</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-white/10 mt-10 pt-6">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-stone-400 text-sm">
              © {new Date().getFullYear()} Stitch & Style. All rights reserved.
            </p>
            <div className="flex space-x-6 mt-4 md:mt-0">
              <Link to="/privacy" className="text-stone-400 hover:text-white text-sm transition-colors">
                Privacy Policy
              </Link>
              <Link to="/terms" className="text-stone-400 hover:text-white text-sm transition-colors">
                Terms of Service
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
