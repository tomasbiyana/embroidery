import { useEffect, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { ArrowLeft, MessageCircle, CheckCircle, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { supabase } from '../lib/supabase';
import { toast } from 'sonner';
import type { User } from '../App';

interface Order {
  id: string;
  product_id: string;
  buyer_id: string;
  quantity: number;
  total_amount: number;
  deposit_amount: number;
  status: string;
  created_at: string;
  updated_at: string;
  product: {
    name: string;
    description: string;
    image_url: string;
    price: number;
    completion_days: number;
    seller: { full_name: string; phone: string };
  };
  buyer: {
    full_name: string;
    email: string;
    phone: string;
  };
  payments: {
    id: string;
    amount: number;
    payment_type: string;
    transaction_id: string;
    platform: string;
    verified: boolean;
    created_at: string;
  }[];
}

interface OrderDetailProps {
  user: User | null;
}

const statusFlow = [
  { key: 'pending_deposit', label: 'Pending Deposit', description: 'Waiting for 10% deposit payment' },
  { key: 'deposit_paid', label: 'Deposit Paid', description: 'Payment submitted, awaiting verification' },
  { key: 'deposit_verified', label: 'Deposit Verified', description: 'Payment confirmed, seller notified' },
  { key: 'in_production', label: 'In Production', description: 'Seller is creating your item' },
  { key: 'ready_for_delivery', label: 'Ready for Delivery', description: 'Item is ready, awaiting final payment' },
  { key: 'final_payment_pending', label: 'Final Payment Pending', description: 'Please pay the remaining 90%' },
  { key: 'completed', label: 'Completed', description: 'Order completed successfully' },
];

export default function OrderDetail({ user: _user }: OrderDetailProps) {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [order, setOrder] = useState<Order | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (id) loadOrder();
  }, [id]);

  const loadOrder = async () => {
    try {
      const { data, error } = await supabase
        .from('orders')
        .select(`
          *,
          product:products(name, description, image_url, price, completion_days, seller:profiles(full_name, phone)),
          buyer:profiles(full_name, email, phone),
          payments:payments(id, amount, payment_type, transaction_id, platform, verified, created_at)
        `)
        .eq('id', id || '')
        .single();

      if (error) throw error;
      setOrder(data as unknown as Order);
    } catch (error) {
      console.error('Error loading order:', error);
      toast.error('Failed to load order');
    } finally {
      setLoading(false);
    }
  };

  const getStatusIndex = (status: string) => {
    return statusFlow.findIndex(s => s.key === status);
  };

  if (loading) {
    return (
      <div className="pt-24 flex justify-center min-h-screen">
        <Loader2 className="w-12 h-12 animate-spin text-[#8b6d4b]" />
      </div>
    );
  }

  if (!order) {
    return (
      <div className="pt-24 text-center min-h-screen">
        <p className="text-stone-500">Order not found</p>
        <Button onClick={() => navigate('/')} className="mt-4">
          Go Home
        </Button>
      </div>
    );
  }

  const currentStatusIndex = getStatusIndex(order.status);
  const remainingAmount = order.total_amount - order.deposit_amount;

  return (
    <div className="pt-24 pb-16 bg-[#fafafa] min-h-screen">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Back Button */}
        <button
          onClick={() => navigate(-1)}
          className="flex items-center text-stone-600 hover:text-[#8b6d4b] mb-6"
        >
          <ArrowLeft className="w-5 h-5 mr-2" />
          Back
        </button>

        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <h1 className="text-3xl font-serif text-stone-900">Order Details</h1>
            <Button variant="outline" asChild>
              <Link to={`/chat/${order.id}`}>
                <MessageCircle className="w-4 h-4 mr-2" />
                Chat
              </Link>
            </Button>
          </div>
          <p className="text-stone-500">Order #{order.id.slice(0, 8)}</p>
        </div>

        {/* Status Timeline */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Order Status</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="relative">
              {/* Progress Bar */}
              <div className="absolute top-4 left-0 right-0 h-1 bg-stone-200">
                <div 
                  className="h-full bg-[#8b6d4b] transition-all duration-500"
                  style={{ width: `${(currentStatusIndex / (statusFlow.length - 1)) * 100}%` }}
                />
              </div>
              
              {/* Status Steps */}
              <div className="relative flex justify-between">
                {statusFlow.map((status, index) => {
                  const isCompleted = index <= currentStatusIndex;
                  const isCurrent = index === currentStatusIndex;
                  
                  return (
                    <div key={status.key} className="flex flex-col items-center">
                      <div 
                        className={`w-8 h-8 rounded-full flex items-center justify-center z-10 ${
                          isCompleted 
                            ? 'bg-[#8b6d4b] text-white' 
                            : 'bg-stone-200 text-stone-400'
                        } ${isCurrent ? 'ring-4 ring-[#8b6d4b]/20' : ''}`}
                      >
                        {isCompleted ? (
                          <CheckCircle className="w-5 h-5" />
                        ) : (
                          <div className="w-3 h-3 rounded-full bg-current" />
                        )}
                      </div>
                      <span className={`text-xs mt-2 text-center max-w-[80px] ${isCurrent ? 'font-semibold text-[#8b6d4b]' : 'text-stone-500'}`}>
                        {status.label}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
            
            <div className="mt-6 p-4 bg-[#8b6d4b]/10 rounded-lg">
              <p className="font-medium text-[#8b6d4b]">
                {statusFlow[currentStatusIndex]?.description}
              </p>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Product Info */}
          <Card>
            <CardHeader>
              <CardTitle>Product Information</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-start space-x-4">
                <img
                  src={order.product?.image_url}
                  alt={order.product?.name}
                  className="w-24 h-24 object-cover rounded-lg"
                />
                <div>
                  <h3 className="font-semibold">{order.product?.name}</h3>
                  <p className="text-stone-500 text-sm mt-1">{order.product?.description}</p>
                  <div className="mt-2 space-y-1">
                    <p className="text-sm"><span className="text-stone-500">Price:</span> ${order.product?.price}</p>
                    <p className="text-sm"><span className="text-stone-500">Quantity:</span> {order.quantity}</p>
                    <p className="text-sm"><span className="text-stone-500">Completion:</span> {order.product?.completion_days} days</p>
                  </div>
                </div>
              </div>
              
              <Separator className="my-4" />
              
              <div>
                <p className="text-sm text-stone-500 mb-1">Seller</p>
                <p className="font-medium">{order.product?.seller?.full_name}</p>
                <p className="text-sm text-stone-500">{order.product?.seller?.phone}</p>
              </div>
            </CardContent>
          </Card>

          {/* Payment Info */}
          <Card>
            <CardHeader>
              <CardTitle>Payment Information</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-stone-500">Total Amount</span>
                  <span className="font-bold">${order.total_amount}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-stone-500">Deposit Paid (10%)</span>
                  <span className="font-bold text-green-600">${order.deposit_amount}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-stone-500">Remaining (90%)</span>
                  <span className="font-bold text-[#8b6d4b]">${remainingAmount}</span>
                </div>
              </div>

              <Separator className="my-4" />

              <div>
                <p className="text-sm font-medium mb-2">Payment History</p>
                {order.payments?.length === 0 ? (
                  <p className="text-stone-500 text-sm">No payments recorded</p>
                ) : (
                  <div className="space-y-2">
                    {order.payments?.map((payment) => (
                      <div key={payment.id} className="p-3 bg-stone-50 rounded-lg">
                        <div className="flex items-center justify-between">
                          <span className="font-medium">{payment.payment_type === 'deposit' ? 'Deposit' : 'Final Payment'}</span>
                          <Badge className={payment.verified ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}>
                            {payment.verified ? 'Verified' : 'Pending'}
                          </Badge>
                        </div>
                        <p className="text-sm text-stone-500">${payment.amount} via {payment.platform}</p>
                        <p className="text-xs text-stone-400">Transaction: {payment.transaction_id}</p>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Order Info */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>Order Information</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-stone-500">Order Date</p>
                <p className="font-medium">{new Date(order.created_at).toLocaleDateString()}</p>
              </div>
              <div>
                <p className="text-sm text-stone-500">Last Updated</p>
                <p className="font-medium">{new Date(order.updated_at).toLocaleDateString()}</p>
              </div>
              <div>
                <p className="text-sm text-stone-500">Buyer</p>
                <p className="font-medium">{order.buyer?.full_name}</p>
                <p className="text-sm text-stone-500">{order.buyer?.email}</p>
                <p className="text-sm text-stone-500">{order.buyer?.phone}</p>
              </div>
              <div>
                <p className="text-sm text-stone-500">Current Status</p>
                <Badge className="mt-1">{order.status.replace(/_/g, ' ')}</Badge>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
