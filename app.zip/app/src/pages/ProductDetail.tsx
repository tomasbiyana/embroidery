import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, ShoppingCart, Clock, User, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { getProductById, addToCart } from '../lib/supabase';
import { toast } from 'sonner';
import type { User as UserType } from '../App';

interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  image_url: string;
  completion_days: number;
  category: string;
  status: string;
  seller: { full_name: string; phone: string };
}

interface ProductDetailProps {
  user: UserType | null;
}

export default function ProductDetail({ user }: ProductDetailProps) {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [product, setProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);
  const [quantity, setQuantity] = useState(1);

  useEffect(() => {
    if (id) loadProduct();
  }, [id]);

  const loadProduct = async () => {
    try {
      const { data, error } = await getProductById(id!);
      if (error) throw error;
      setProduct(data as unknown as Product);
    } catch (error) {
      console.error('Error loading product:', error);
      toast.error('Failed to load product');
    } finally {
      setLoading(false);
    }
  };

  const handleAddToCart = () => {
    if (!user) {
      toast.error('Please login to add items to cart');
      navigate('/login');
      return;
    }
    if (!product) return;

    addToCart({
      product_id: product.id,
      name: product.name,
      price: product.price,
      image_url: product.image_url,
      quantity,
    });
    toast.success(`${product.name} added to cart!`);
  };

  const handleBuyNow = () => {
    if (!user) {
      toast.error('Please login to purchase');
      navigate('/login');
      return;
    }
    handleAddToCart();
    navigate('/cart');
  };

  if (loading) {
    return (
      <div className="pt-24 flex justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#8b6d4b]" />
      </div>
    );
  }

  if (!product) {
    return (
      <div className="pt-24 text-center min-h-screen">
        <p className="text-stone-500">Product not found</p>
        <Button onClick={() => navigate('/')} className="mt-4">
          Go Home
        </Button>
      </div>
    );
  }

  const depositAmount = (product.price * 0.1).toFixed(2);

  return (
    <div className="pt-20 pb-16 bg-[#fafafa] min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Back Button */}
        <button
          onClick={() => navigate(-1)}
          className="flex items-center text-stone-600 hover:text-[#8b6d4b] mb-6"
        >
          <ArrowLeft className="w-5 h-5 mr-2" />
          Back
        </button>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Product Image */}
          <div className="bg-white rounded-lg overflow-hidden shadow-sm">
            <img
              src={product.image_url}
              alt={product.name}
              className="w-full h-[500px] object-cover"
            />
          </div>

          {/* Product Info */}
          <div>
            <Badge className="mb-4 bg-[#8b6d4b]/10 text-[#8b6d4b]">
              {product.category}
            </Badge>
            
            <h1 className="text-4xl font-serif text-stone-900 mb-4">{product.name}</h1>
            
            <div className="flex items-center space-x-4 mb-6">
              <span className="text-3xl font-bold text-[#8b6d4b]">${product.price}</span>
              <span className="text-stone-400">|</span>
              <div className="flex items-center text-stone-600">
                <Clock className="w-5 h-5 mr-2" />
                <span>{product.completion_days} days to complete</span>
              </div>
            </div>

            <Separator className="my-6" />

            <div className="prose prose-stone mb-8">
              <h3 className="text-lg font-semibold mb-2">Description</h3>
              <p className="text-stone-600">{product.description}</p>
            </div>

            <div className="bg-[#fafafa] p-4 rounded-lg mb-6">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-[#8b6d4b] rounded-full flex items-center justify-center">
                  <User className="w-5 h-5 text-white" />
                </div>
                <div>
                  <p className="font-medium">{product.seller?.full_name}</p>
                  <p className="text-sm text-stone-500">Artisan Seller</p>
                </div>
              </div>
            </div>

            {/* Payment Info */}
            <Card className="mb-6 border-[#8b6d4b]/20">
              <CardContent className="p-4">
                <h3 className="font-semibold mb-3 flex items-center">
                  <Check className="w-5 h-5 text-green-500 mr-2" />
                  Payment Process
                </h3>
                <ul className="space-y-2 text-sm text-stone-600">
                  <li className="flex items-start">
                    <span className="w-6 h-6 rounded-full bg-[#8b6d4b] text-white text-xs flex items-center justify-center mr-2 flex-shrink-0">1</span>
                    Pay 10% deposit (${depositAmount}) to place order
                  </li>
                  <li className="flex items-start">
                    <span className="w-6 h-6 rounded-full bg-[#8b6d4b] text-white text-xs flex items-center justify-center mr-2 flex-shrink-0">2</span>
                    Admin verifies your payment
                  </li>
                  <li className="flex items-start">
                    <span className="w-6 h-6 rounded-full bg-[#8b6d4b] text-white text-xs flex items-center justify-center mr-2 flex-shrink-0">3</span>
                    Seller creates your item ({product.completion_days} days)
                  </li>
                  <li className="flex items-start">
                    <span className="w-6 h-6 rounded-full bg-[#8b6d4b] text-white text-xs flex items-center justify-center mr-2 flex-shrink-0">4</span>
                    Pay 90% balance on delivery
                  </li>
                </ul>
              </CardContent>
            </Card>

            {/* Quantity Selector */}
            <div className="flex items-center space-x-4 mb-6">
              <span className="font-medium">Quantity:</span>
              <div className="flex items-center border border-stone-300 rounded-lg">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="px-4 py-2 hover:bg-stone-100"
                >
                  -
                </button>
                <span className="px-4 py-2 border-x border-stone-300">{quantity}</span>
                <button
                  onClick={() => setQuantity(quantity + 1)}
                  className="px-4 py-2 hover:bg-stone-100"
                >
                  +
                </button>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-4">
              <Button
                size="lg"
                className="flex-1 bg-[#8b6d4b] hover:bg-[#6d5639] text-white"
                onClick={handleAddToCart}
              >
                <ShoppingCart className="w-5 h-5 mr-2" />
                Add to Cart
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="flex-1 border-[#8b6d4b] text-[#8b6d4b] hover:bg-[#8b6d4b] hover:text-white"
                onClick={handleBuyNow}
              >
                Buy Now
              </Button>
            </div>

            {!user && (
              <p className="text-sm text-stone-500 mt-4 text-center">
                Please <button onClick={() => navigate('/login')} className="text-[#8b6d4b] underline">login</button> to purchase
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
