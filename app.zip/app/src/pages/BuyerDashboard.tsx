import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Package, MessageCircle, Clock, CheckCircle, AlertCircle, ChevronRight, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { supabase } from '../lib/supabase';
import { toast } from 'sonner';
import type { User } from '../App';

interface Order {
  id: string;
  product: {
    name: string;
    image_url: string;
    price: number;
    seller_id: string;
  };
  quantity: number;
  total_amount: number;
  deposit_amount: number;
  status: string;
  created_at: string;
  payments: { verified: boolean }[];
}

interface BuyerDashboardProps {
  user: User | null;
}

const statusLabels: Record<string, { label: string; color: string; icon: any }> = {
  pending_deposit: { label: 'Pending Deposit', color: 'bg-yellow-100 text-yellow-800', icon: Clock },
  deposit_paid: { label: 'Deposit Paid', color: 'bg-blue-100 text-blue-800', icon: CheckCircle },
  deposit_verified: { label: 'Deposit Verified', color: 'bg-green-100 text-green-800', icon: CheckCircle },
  in_production: { label: 'In Production', color: 'bg-purple-100 text-purple-800', icon: Loader2 },
  ready_for_delivery: { label: 'Ready for Delivery', color: 'bg-teal-100 text-teal-800', icon: Package },
  final_payment_pending: { label: 'Final Payment Pending', color: 'bg-orange-100 text-orange-800', icon: AlertCircle },
  completed: { label: 'Completed', color: 'bg-green-100 text-green-800', icon: CheckCircle },
  cancelled: { label: 'Cancelled', color: 'bg-red-100 text-red-800', icon: AlertCircle },
};

export default function BuyerDashboard({ user }: BuyerDashboardProps) {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    total: 0,
    active: 0,
    completed: 0,
  });

  useEffect(() => {
    if (user) loadOrders();
  }, [user]);

  const loadOrders = async () => {
    try {
      const { data, error } = await supabase
        .from('orders')
        .select(`
          *,
          product:products(name, image_url, price, seller_id),
          payments:payments(verified)
        `)
        .eq('buyer_id', user!.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      
      const ordersData = data || [];
      setOrders(ordersData);
      
      setStats({
        total: ordersData.length,
        active: ordersData.filter((o: Order) => !['completed', 'cancelled'].includes(o.status)).length,
        completed: ordersData.filter((o: Order) => o.status === 'completed').length,
      });
    } catch (error) {
      console.error('Error loading orders:', error);
      toast.error('Failed to load orders');
    } finally {
      setLoading(false);
    }
  };

  const getStatusBadge = (status: string) => {
    const config = statusLabels[status] || statusLabels.pending_deposit;
    return (
      <Badge className={config.color}>
        <config.icon className="w-3 h-3 mr-1" />
        {config.label}
      </Badge>
    );
  };

  if (!user) return null;

  return (
    <div className="pt-24 pb-16 bg-[#fafafa] min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-serif text-stone-900">My Dashboard</h1>
          <p className="text-stone-600">Welcome back, {user.full_name}</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-stone-500 text-sm">Total Orders</p>
                  <p className="text-3xl font-bold">{stats.total}</p>
                </div>
                <div className="w-12 h-12 bg-[#8b6d4b]/10 rounded-lg flex items-center justify-center">
                  <Package className="w-6 h-6 text-[#8b6d4b]" />
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-stone-500 text-sm">Active Orders</p>
                  <p className="text-3xl font-bold">{stats.active}</p>
                </div>
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                  <Loader2 className="w-6 h-6 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-stone-500 text-sm">Completed</p>
                  <p className="text-3xl font-bold">{stats.completed}</p>
                </div>
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                  <CheckCircle className="w-6 h-6 text-green-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Orders Tabs */}
        <Tabs defaultValue="all" className="space-y-6">
          <TabsList>
            <TabsTrigger value="all">All Orders</TabsTrigger>
            <TabsTrigger value="active">Active</TabsTrigger>
            <TabsTrigger value="completed">Completed</TabsTrigger>
          </TabsList>

          <TabsContent value="all">
            <OrdersList orders={orders} loading={loading} getStatusBadge={getStatusBadge} />
          </TabsContent>

          <TabsContent value="active">
            <OrdersList 
              orders={orders.filter(o => !['completed', 'cancelled'].includes(o.status))} 
              loading={loading} 
              getStatusBadge={getStatusBadge} 
            />
          </TabsContent>

          <TabsContent value="completed">
            <OrdersList 
              orders={orders.filter(o => o.status === 'completed')} 
              loading={loading} 
              getStatusBadge={getStatusBadge} 
            />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

interface OrdersListProps {
  orders: Order[];
  loading: boolean;
  getStatusBadge: (status: string) => React.ReactElement;
}

function OrdersList({ orders, loading, getStatusBadge }: OrdersListProps) {
  if (loading) {
    return (
      <div className="flex justify-center py-12">
        <Loader2 className="w-8 h-8 animate-spin text-[#8b6d4b]" />
      </div>
    );
  }

  if (orders.length === 0) {
    return (
      <Card>
        <CardContent className="p-12 text-center">
          <Package className="w-16 h-16 text-stone-300 mx-auto mb-4" />
          <h3 className="text-lg font-semibold mb-2">No orders found</h3>
          <p className="text-stone-500 mb-4">Start shopping to see your orders here</p>
          <Button asChild className="bg-[#8b6d4b] hover:bg-[#6d5639]">
            <Link to="/">Browse Products</Link>
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      {orders.map((order) => (
        <Card key={order.id} className="overflow-hidden">
          <CardContent className="p-0">
            <div className="flex flex-col md:flex-row">
              {/* Product Image */}
              <div className="w-full md:w-48 h-48">
                <img
                  src={order.product?.image_url}
                  alt={order.product?.name}
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Order Details */}
              <div className="flex-1 p-6">
                <div className="flex flex-col md:flex-row md:items-start md:justify-between">
                  <div>
                    <h3 className="font-semibold text-lg mb-1">{order.product?.name}</h3>
                    <p className="text-stone-500 text-sm mb-2">
                      Order #{order.id.slice(0, 8)}
                    </p>
                    <div className="flex items-center space-x-4 mb-4">
                      <span className="text-[#8b6d4b] font-bold">${order.total_amount}</span>
                      <span className="text-stone-400">|</span>
                      <span className="text-stone-600">Qty: {order.quantity}</span>
                    </div>
                    {getStatusBadge(order.status)}
                  </div>

                  <div className="mt-4 md:mt-0 md:text-right">
                    <p className="text-sm text-stone-500">
                      {new Date(order.created_at).toLocaleDateString()}
                    </p>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex flex-wrap gap-2 mt-4 pt-4 border-t">
                  <Button
                    variant="outline"
                    size="sm"
                    asChild
                  >
                    <Link to={`/order/${order.id}`}>
                      View Details <ChevronRight className="w-4 h-4 ml-1" />
                    </Link>
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    asChild
                  >
                    <Link to={`/chat/${order.id}`}>
                      <MessageCircle className="w-4 h-4 mr-1" />
                      Chat
                    </Link>
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
