import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, ShoppingBag, Heart, Truck, Shield, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { getProducts, addToCart } from '../lib/supabase';
import { toast } from 'sonner';
import type { User } from '../App';

interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  image_url: string;
  completion_days: number;
  category: string;
  seller: { full_name: string };
}

interface HomeProps {
  user: User | null;
}

export default function Home({ user }: HomeProps) {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState('All');

  const categories = ['All', 'Small Bags', 'Clothing', 'Home Decor', 'Accessories'];

  useEffect(() => {
    loadProducts();
  }, []);

  const loadProducts = async () => {
    try {
      const { data, error } = await getProducts('approved');
      if (error) throw error;
      setProducts(data || []);
    } catch (error) {
      console.error('Error loading products:', error);
      toast.error('Failed to load products');
    } finally {
      setLoading(false);
    }
  };

  const handleAddToCart = (product: Product) => {
    if (!user) {
      toast.error('Please login to add items to cart');
      return;
    }
    addToCart({
      product_id: product.id,
      name: product.name,
      price: product.price,
      image_url: product.image_url,
      quantity: 1,
    });
    toast.success(`${product.name} added to cart!`);
  };

  const filteredProducts = selectedCategory === 'All' 
    ? products 
    : products.filter(p => p.category === selectedCategory);

  return (
    <div className="pt-16">
      {/* Hero Section */}
      <section className="relative h-[600px] flex items-center justify-center overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-fixed"
          style={{ 
            backgroundImage: 'url(https://images.unsplash.com/photo-1558171813-4c088753af8f?w=1920&q=80)',
          }}
        >
          <div className="absolute inset-0 bg-black/40" />
        </div>
        
        <div className="relative z-10 text-center text-white px-4 max-w-4xl mx-auto">
          <p className="text-sm uppercase tracking-widest mb-4 text-[#c9a87c]">Handcrafted with Love</p>
          <h1 className="text-5xl md:text-7xl font-serif mb-6 leading-tight">
            Beautiful Embroidery &<br />Handmade Crafts
          </h1>
          <p className="text-lg md:text-xl mb-8 text-white/90 max-w-2xl mx-auto">
            Discover unique, handcrafted items made by talented artisans. Each piece tells a story of tradition and craftsmanship.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg" 
              className="bg-[#8b6d4b] hover:bg-[#6d5639] text-white px-8"
              asChild
            >
              <Link to="#products">
                Shop Now <ArrowRight className="ml-2 w-5 h-5" />
              </Link>
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="border-white text-white hover:bg-white hover:text-stone-900 px-8"
              asChild
            >
              <Link to="#about">Learn More</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {[
              { icon: Heart, title: 'Handcrafted', desc: 'Each item made with care' },
              { icon: Shield, title: 'Secure Payment', desc: 'Local bank & mobile transfer' },
              { icon: Truck, title: 'Delivery', desc: 'Safe delivery to your door' },
              { icon: Clock, title: 'Made to Order', desc: 'Custom completion time' },
            ].map((feature, idx) => (
              <div key={idx} className="flex flex-col items-center text-center">
                <div className="w-14 h-14 rounded-full bg-[#8b6d4b]/10 flex items-center justify-center mb-4">
                  <feature.icon className="w-7 h-7 text-[#8b6d4b]" />
                </div>
                <h3 className="font-semibold text-lg mb-2">{feature.title}</h3>
                <p className="text-stone-600 text-sm">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Products Section */}
      <section id="products" className="py-20 bg-[#fafafa]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <p className="text-sm uppercase tracking-widest text-[#8b6d4b] mb-2">Our Collection</p>
            <h2 className="text-4xl font-serif text-stone-900 mb-4">Featured Products</h2>
            <p className="text-stone-600 max-w-2xl mx-auto">
              Browse our curated collection of handcrafted embroidery and handmade items
            </p>
          </div>

          {/* Category Filter */}
          <div className="flex flex-wrap justify-center gap-2 mb-10">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                  selectedCategory === category
                    ? 'bg-[#8b6d4b] text-white'
                    : 'bg-white text-stone-600 hover:bg-stone-100'
                }`}
              >
                {category}
              </button>
            ))}
          </div>

          {/* Products Grid */}
          {loading ? (
            <div className="flex justify-center py-12">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#8b6d4b]" />
            </div>
          ) : filteredProducts.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-stone-500">No products found in this category</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {filteredProducts.slice(0, 8).map((product) => (
                <Card key={product.id} className="group overflow-hidden bg-white border-0 shadow-sm hover:shadow-lg transition-shadow">
                  <div className="relative aspect-square overflow-hidden">
                    <img
                      src={product.image_url}
                      alt={product.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors" />
                    <button
                      onClick={() => handleAddToCart(product)}
                      className="absolute bottom-4 left-4 right-4 bg-white text-stone-900 py-2 rounded-lg font-medium opacity-0 group-hover:opacity-100 transform translate-y-2 group-hover:translate-y-0 transition-all duration-300 flex items-center justify-center gap-2 hover:bg-[#8b6d4b] hover:text-white"
                    >
                      <ShoppingBag className="w-4 h-4" />
                      Add to Cart
                    </button>
                  </div>
                  <CardContent className="p-4">
                    <Badge variant="secondary" className="mb-2 bg-stone-100 text-stone-600">
                      {product.category}
                    </Badge>
                    <h3 className="font-semibold text-lg mb-1 group-hover:text-[#8b6d4b] transition-colors">
                      <Link to={`/product/${product.id}`}>{product.name}</Link>
                    </h3>
                    <p className="text-stone-500 text-sm mb-2 line-clamp-2">{product.description}</p>
                    <div className="flex items-center justify-between">
                      <span className="text-xl font-bold text-[#8b6d4b]">${product.price}</span>
                      <span className="text-xs text-stone-400">{product.completion_days} days</span>
                    </div>
                    <p className="text-xs text-stone-400 mt-2">by {product.seller?.full_name}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}

          <div className="text-center mt-10">
            <Button variant="outline" className="border-[#8b6d4b] text-[#8b6d4b] hover:bg-[#8b6d4b] hover:text-white">
              View All Products <ArrowRight className="ml-2 w-4 h-4" />
            </Button>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="relative">
              <img
                src="https://images.unsplash.com/photo-1452860606245-08befc0ff44b?w=800&q=80"
                alt="Artisan at work"
                className="rounded-lg shadow-xl"
              />
              <div className="absolute -bottom-6 -right-6 bg-[#8b6d4b] text-white p-6 rounded-lg">
                <p className="text-3xl font-bold">500+</p>
                <p className="text-sm">Happy Customers</p>
              </div>
            </div>
            <div>
              <p className="text-sm uppercase tracking-widest text-[#8b6d4b] mb-2">About Us</p>
              <h2 className="text-4xl font-serif text-stone-900 mb-6">Preserving the Art of Hand Embroidery</h2>
              <p className="text-stone-600 mb-4">
                At Stitch & Style, we believe in the beauty of handmade crafts. Our platform connects talented artisans with customers who appreciate the time, skill, and love that goes into each handcrafted piece.
              </p>
              <p className="text-stone-600 mb-6">
                Every item on our platform is made to order, ensuring that you receive a unique piece crafted specifically for you. From small bags to clothing and home decor, our sellers create beautiful items that tell a story.
              </p>
              <div className="grid grid-cols-3 gap-6 mb-8">
                <div className="text-center">
                  <p className="text-3xl font-bold text-[#8b6d4b]">50+</p>
                  <p className="text-sm text-stone-600">Artisans</p>
                </div>
                <div className="text-center">
                  <p className="text-3xl font-bold text-[#8b6d4b]">1000+</p>
                  <p className="text-sm text-stone-600">Products</p>
                </div>
                <div className="text-center">
                  <p className="text-3xl font-bold text-[#8b6d4b]">4.9</p>
                  <p className="text-sm text-stone-600">Rating</p>
                </div>
              </div>
              <Button className="bg-[#8b6d4b] hover:bg-[#6d5639] text-white">
                Learn More About Us
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 bg-[#fafafa]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <p className="text-sm uppercase tracking-widest text-[#8b6d4b] mb-2">How It Works</p>
            <h2 className="text-4xl font-serif text-stone-900 mb-4">Simple Steps to Order</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {[
              { step: '01', title: 'Browse', desc: 'Explore our collection of handcrafted items' },
              { step: '02', title: 'Order', desc: 'Add to cart and pay 10% deposit' },
              { step: '03', title: 'Create', desc: 'Seller crafts your item with care' },
              { step: '04', title: 'Receive', desc: 'Pay balance and receive your item' },
            ].map((item, idx) => (
              <div key={idx} className="relative text-center">
                <div className="w-20 h-20 mx-auto bg-[#8b6d4b] text-white rounded-full flex items-center justify-center text-2xl font-bold mb-4">
                  {item.step}
                </div>
                <h3 className="font-semibold text-xl mb-2">{item.title}</h3>
                <p className="text-stone-600">{item.desc}</p>
                {idx < 3 && (
                  <div className="hidden md:block absolute top-10 left-[60%] w-full h-0.5 bg-[#8b6d4b]/20" />
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-[#8b6d4b]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-white">
          <h2 className="text-4xl font-serif mb-4">Become a Seller</h2>
          <p className="text-lg mb-8 text-white/90">
            Are you a talented artisan? Join our platform and showcase your handcrafted items to customers worldwide.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg" 
              className="bg-white text-[#8b6d4b] hover:bg-stone-100"
              asChild
            >
              <Link to="/register">Start Selling</Link>
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="border-white text-white hover:bg-white/10"
            >
              Learn More
            </Button>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <div>
              <p className="text-sm uppercase tracking-widest text-[#8b6d4b] mb-2">Contact Us</p>
              <h2 className="text-4xl font-serif text-stone-900 mb-6">Get in Touch</h2>
              <p className="text-stone-600 mb-8">
                Have questions about an order or want to learn more about our platform? We're here to help!
              </p>
              
              <div className="space-y-4">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-[#8b6d4b]/10 rounded-lg flex items-center justify-center">
                    <svg className="w-6 h-6 text-[#8b6d4b]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                    </svg>
                  </div>
                  <div>
                    <p className="font-medium">Phone</p>
                    <p className="text-stone-600">+1 (234) 567-8900</p>
                  </div>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-[#8b6d4b]/10 rounded-lg flex items-center justify-center">
                    <svg className="w-6 h-6 text-[#8b6d4b]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                    </svg>
                  </div>
                  <div>
                    <p className="font-medium">Email</p>
                    <p className="text-stone-600">hello@stitchandstyle.com</p>
                  </div>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-[#8b6d4b]/10 rounded-lg flex items-center justify-center">
                    <svg className="w-6 h-6 text-[#8b6d4b]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                    </svg>
                  </div>
                  <div>
                    <p className="font-medium">Address</p>
                    <p className="text-stone-600">123 Craft Street, Creative City</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-[#fafafa] p-8 rounded-lg">
              <form className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="name">Name</Label>
                    <Input id="name" placeholder="Your name" />
                  </div>
                  <div>
                    <Label htmlFor="email">Email</Label>
                    <Input id="email" type="email" placeholder="your@email.com" />
                  </div>
                </div>
                <div>
                  <Label htmlFor="subject">Subject</Label>
                  <Input id="subject" placeholder="How can we help?" />
                </div>
                <div>
                  <Label htmlFor="message">Message</Label>
                  <textarea
                    id="message"
                    rows={4}
                    className="w-full px-3 py-2 border border-stone-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#8b6d4b] focus:border-transparent"
                    placeholder="Your message..."
                  />
                </div>
                <Button className="w-full bg-[#8b6d4b] hover:bg-[#6d5639] text-white">
                  Send Message
                </Button>
              </form>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
