import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  MessageCircle, CheckCircle, XCircle, 
  Eye, Loader2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { supabase } from '../lib/supabase';
import { toast } from 'sonner';
import type { User } from '../App';

interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  image_url: string;
  category: string;
  status: string;
  seller: { full_name: string; email: string };
  created_at: string;
}

interface Payment {
  id: string;
  order_id: string;
  amount: number;
  payment_type: string;
  transaction_id: string;
  platform: string;
  sent_to: string;
  payment_date: string;
  notes: string;
  verified: boolean;
  created_at: string;
  order: {
    product: { name: string; image_url: string };
    buyer: { full_name: string; email: string };
  };
}

interface Order {
  id: string;
  status: string;
  total_amount: number;
  deposit_amount: number;
  created_at: string;
  product: { name: string; image_url: string };
  buyer: { full_name: string };
}

interface AdminDashboardProps {
  user: User | null;
}

export default function AdminDashboard({ user }: AdminDashboardProps) {
  const [products, setProducts] = useState<Product[]>([]);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [users, setUsers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [stats, setStats] = useState({
    totalUsers: 0,
    totalProducts: 0,
    totalOrders: 0,
    pendingPayments: 0,
    pendingProducts: 0,
    totalRevenue: 0,
  });

  useEffect(() => {
    if (user) {
      loadData();
    }
  }, [user]);

  const loadData = async () => {
    setLoading(true);
    try {
      // Load products
      const { data: productsData } = await supabase
        .from('products')
        .select('*, seller:profiles(full_name, email)')
        .order('created_at', { ascending: false });
      setProducts(productsData || []);

      // Load payments
      const { data: paymentsData } = await supabase
        .from('payments')
        .select(`
          *,
          order:orders(
            product:products(name, image_url),
            buyer:profiles(full_name, email)
          )
        `)
        .order('created_at', { ascending: false });
      setPayments(paymentsData || []);

      // Load orders
      const { data: ordersData } = await supabase
        .from('orders')
        .select(`
          *,
          product:products(name, image_url),
          buyer:profiles(full_name)
        `)
        .order('created_at', { ascending: false });
      setOrders(ordersData || []);

      // Load users
      const { data: usersData } = await supabase
        .from('profiles')
        .select('*')
        .order('created_at', { ascending: false });
      setUsers(usersData || []);

      // Calculate stats
      setStats({
        totalUsers: usersData?.length || 0,
        totalProducts: productsData?.length || 0,
        totalOrders: ordersData?.length || 0,
        pendingPayments: paymentsData?.filter((p: Payment) => !p.verified).length || 0,
        pendingProducts: productsData?.filter((p: Product) => p.status === 'pending').length || 0,
        totalRevenue: ordersData?.reduce((sum: number, o: Order) => sum + (o.total_amount || 0), 0) || 0,
      });
    } catch (error) {
      console.error('Error loading data:', error);
      toast.error('Failed to load dashboard data');
    } finally {
      setLoading(false);
    }
  };

  const handleApproveProduct = async (id: string, status: 'approved' | 'rejected') => {
    try {
      const { error } = await (supabase as any)
        .from('products')
        .update({ status })
        .eq('id', id);

      if (error) throw error;
      toast.success(`Product ${status}`);
      loadData();
    } catch (error) {
      toast.error('Failed to update product');
    }
  };

  const handleVerifyPayment = async (paymentId: string, orderId: string, verified: boolean) => {
    try {
      // Update payment status
      const { error: paymentError } = await (supabase as any)
        .from('payments')
        .update({ verified, verified_at: new Date().toISOString() })
        .eq('id', paymentId);

      if (paymentError) throw paymentError;

      // Update order status
      const { error: orderError } = await (supabase as any)
        .from('orders')
        .update({ status: verified ? 'deposit_verified' : 'pending_deposit' })
        .eq('id', orderId);

      if (orderError) throw orderError;

      toast.success(verified ? 'Payment verified' : 'Payment rejected');
      loadData();
    } catch (error) {
      toast.error('Failed to verify payment');
    }
  };

  const handleUpdateOrderStatus = async (orderId: string, status: string) => {
    try {
      const { error } = await supabase
        .from('orders')
        .update({ status })
        .eq('id', orderId);

      if (error) throw error;
      toast.success('Order status updated');
      loadData();
    } catch (error) {
      toast.error('Failed to update order');
    }
  };

  if (!user) return null;

  return (
    <div className="pt-24 pb-16 bg-[#fafafa] min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-serif text-stone-900">Admin Dashboard</h1>
          <p className="text-stone-600">Manage products, orders, and payments</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-8">
          <Card>
            <CardContent className="p-4">
              <p className="text-stone-500 text-xs">Users</p>
              <p className="text-2xl font-bold">{stats.totalUsers}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <p className="text-stone-500 text-xs">Products</p>
              <p className="text-2xl font-bold">{stats.totalProducts}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <p className="text-stone-500 text-xs">Orders</p>
              <p className="text-2xl font-bold">{stats.totalOrders}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <p className="text-stone-500 text-xs">Revenue</p>
              <p className="text-2xl font-bold">${stats.totalRevenue.toFixed(0)}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <p className="text-stone-500 text-xs">Pending Products</p>
              <p className="text-2xl font-bold text-yellow-600">{stats.pendingProducts}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <p className="text-stone-500 text-xs">Pending Payments</p>
              <p className="text-2xl font-bold text-orange-600">{stats.pendingPayments}</p>
            </CardContent>
          </Card>
        </div>

        {/* Tabs */}
        <Tabs defaultValue="products" className="space-y-6">
          <TabsList className="flex-wrap">
            <TabsTrigger value="products">Pending Products</TabsTrigger>
            <TabsTrigger value="payments">Pending Payments</TabsTrigger>
            <TabsTrigger value="orders">All Orders</TabsTrigger>
            <TabsTrigger value="users">Users</TabsTrigger>
          </TabsList>

          <TabsContent value="products">
            <ProductsList 
              products={products.filter(p => p.status === 'pending')} 
              loading={loading}
              onApprove={handleApproveProduct}
              onView={setSelectedProduct}
            />
          </TabsContent>

          <TabsContent value="payments">
            <PaymentsList 
              payments={payments.filter(p => !p.verified)} 
              loading={loading}
              onVerify={handleVerifyPayment}
            />
          </TabsContent>

          <TabsContent value="orders">
            <OrdersList 
              orders={orders} 
              loading={loading}
              onUpdateStatus={handleUpdateOrderStatus}
            />
          </TabsContent>

          <TabsContent value="users">
            <UsersList users={users} loading={loading} />
          </TabsContent>
        </Tabs>

        {/* Product Detail Dialog */}
        <Dialog open={!!selectedProduct} onOpenChange={() => setSelectedProduct(null)}>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle>{selectedProduct?.name}</DialogTitle>
            </DialogHeader>
            {selectedProduct && (
              <div className="space-y-4">
                <img
                  src={selectedProduct.image_url}
                  alt={selectedProduct.name}
                  className="w-full h-64 object-cover rounded-lg"
                />
                <p className="text-stone-600">{selectedProduct.description}</p>
                <div className="flex justify-between">
                  <span className="font-bold text-[#8b6d4b]">${selectedProduct.price}</span>
                  <Badge>{selectedProduct.category}</Badge>
                </div>
                <p className="text-sm text-stone-500">
                  Seller: {selectedProduct.seller?.full_name} ({selectedProduct.seller?.email})
                </p>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}

function ProductsList({ products, loading, onApprove, onView }: { 
  products: Product[]; 
  loading: boolean;
  onApprove: (id: string, status: 'approved' | 'rejected') => void;
  onView: (p: Product) => void;
}) {
  if (loading) return <div className="flex justify-center py-12"><Loader2 className="w-8 h-8 animate-spin" /></div>;
  
  if (products.length === 0) {
    return (
      <Card>
        <CardContent className="p-12 text-center">
          <CheckCircle className="w-16 h-16 text-green-300 mx-auto mb-4" />
          <h3 className="text-lg font-semibold">No pending products</h3>
          <p className="text-stone-500">All products have been reviewed</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      {products.map((product) => (
        <Card key={product.id}>
          <CardContent className="p-4">
            <div className="flex items-center space-x-4">
              <img
                src={product.image_url}
                alt={product.name}
                className="w-24 h-24 object-cover rounded-lg"
              />
              <div className="flex-1">
                <h4 className="font-semibold">{product.name}</h4>
                <p className="text-sm text-stone-500">{product.seller?.full_name}</p>
                <p className="text-[#8b6d4b] font-bold">${product.price}</p>
                <Badge className="mt-1">{product.category}</Badge>
              </div>
              <div className="flex gap-2">
                <Button size="sm" variant="outline" onClick={() => onView(product)}>
                  <Eye className="w-4 h-4" />
                </Button>
                <Button size="sm" className="bg-green-600 hover:bg-green-700" onClick={() => onApprove(product.id, 'approved')}>
                  <CheckCircle className="w-4 h-4" />
                </Button>
                <Button size="sm" variant="destructive" onClick={() => onApprove(product.id, 'rejected')}>
                  <XCircle className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

function PaymentsList({ payments, loading, onVerify }: { 
  payments: Payment[]; 
  loading: boolean;
  onVerify: (paymentId: string, orderId: string, verified: boolean) => void;
}) {
  if (loading) return <div className="flex justify-center py-12"><Loader2 className="w-8 h-8 animate-spin" /></div>;
  
  if (payments.length === 0) {
    return (
      <Card>
        <CardContent className="p-12 text-center">
          <CheckCircle className="w-16 h-16 text-green-300 mx-auto mb-4" />
          <h3 className="text-lg font-semibold">No pending payments</h3>
          <p className="text-stone-500">All payments have been verified</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      {payments.map((payment) => (
        <Card key={payment.id}>
          <CardContent className="p-4">
            <div className="flex items-center space-x-4">
              <img
                src={payment.order?.product?.image_url}
                alt={payment.order?.product?.name}
                className="w-24 h-24 object-cover rounded-lg"
              />
              <div className="flex-1">
                <h4 className="font-semibold">{payment.order?.product?.name}</h4>
                <p className="text-sm text-stone-500">Buyer: {payment.order?.buyer?.full_name}</p>
                <p className="text-[#8b6d4b] font-bold">${payment.amount} ({payment.payment_type})</p>
                <p className="text-sm text-stone-500">Platform: {payment.platform}</p>
                <p className="text-sm text-stone-500">Transaction ID: {payment.transaction_id}</p>
              </div>
              <div className="flex gap-2">
                <Button 
                  size="sm" 
                  className="bg-green-600 hover:bg-green-700" 
                  onClick={() => onVerify(payment.id, payment.order_id, true)}
                >
                  <CheckCircle className="w-4 h-4 mr-1" />
                  Verify
                </Button>
                <Button 
                  size="sm" 
                  variant="destructive" 
                  onClick={() => onVerify(payment.id, payment.order_id, false)}
                >
                  <XCircle className="w-4 h-4 mr-1" />
                  Reject
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

function OrdersList({ orders, loading, onUpdateStatus }: { 
  orders: Order[]; 
  loading: boolean;
  onUpdateStatus: (orderId: string, status: string) => void;
}) {
  const statusOptions = [
    'pending_deposit', 'deposit_paid', 'deposit_verified', 'in_production', 
    'ready_for_delivery', 'final_payment_pending', 'completed', 'cancelled'
  ];

  if (loading) return <div className="flex justify-center py-12"><Loader2 className="w-8 h-8 animate-spin" /></div>;

  return (
    <div className="space-y-4">
      {orders.map((order) => (
        <Card key={order.id}>
          <CardContent className="p-4">
            <div className="flex items-center space-x-4">
              <img
                src={order.product?.image_url}
                alt={order.product?.name}
                className="w-20 h-20 object-cover rounded-lg"
              />
              <div className="flex-1">
                <h4 className="font-semibold">{order.product?.name}</h4>
                <p className="text-sm text-stone-500">Buyer: {order.buyer?.full_name}</p>
                <p className="text-[#8b6d4b] font-bold">${order.total_amount}</p>
                <Badge className="mt-1">{order.status}</Badge>
              </div>
              <div>
                <select
                  value={order.status}
                  onChange={(e) => onUpdateStatus(order.id, e.target.value)}
                  className="text-sm border rounded px-2 py-1"
                >
                  {statusOptions.map((s) => (
                    <option key={s} value={s}>{s}</option>
                  ))}
                </select>
                <Button size="sm" variant="outline" className="mt-2 w-full" asChild>
                  <Link to={`/chat/${order.id}`}>
                    <MessageCircle className="w-4 h-4 mr-1" />
                    Chat
                  </Link>
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

function UsersList({ users, loading }: { users: any[]; loading: boolean }) {
  if (loading) return <div className="flex justify-center py-12"><Loader2 className="w-8 h-8 animate-spin" /></div>;

  return (
    <Card>
      <CardContent className="p-0">
        <table className="w-full">
          <thead className="bg-stone-50">
            <tr>
              <th className="text-left p-4">Name</th>
              <th className="text-left p-4">Email</th>
              <th className="text-left p-4">Role</th>
              <th className="text-left p-4">Phone</th>
            </tr>
          </thead>
          <tbody>
            {users.map((user) => (
              <tr key={user.id} className="border-t">
                <td className="p-4">{user.full_name}</td>
                <td className="p-4">{user.email}</td>
                <td className="p-4">
                  <Badge className={
                    user.role === 'admin' ? 'bg-purple-100 text-purple-800' :
                    user.role === 'seller' ? 'bg-blue-100 text-blue-800' :
                    'bg-green-100 text-green-800'
                  }>
                    {user.role}
                  </Badge>
                </td>
                <td className="p-4">{user.phone}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </CardContent>
    </Card>
  );
}
