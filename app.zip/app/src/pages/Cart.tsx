import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Trash2, ArrowLeft, CreditCard, Smartphone, Building2, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { getCart, removeFromCart, clearCart, createOrder, submitPayment } from '../lib/supabase';
import { toast } from 'sonner';
import type { User } from '../App';

interface CartItem {
  product_id: string;
  name: string;
  price: number;
  image_url: string;
  quantity: number;
}

interface CartProps {
  user: User | null;
}

export default function Cart({ user }: CartProps) {
  const navigate = useNavigate();
  const [cart, setCart] = useState<CartItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [showPaymentForm, setShowPaymentForm] = useState(false);
  const [paymentData, setPaymentData] = useState({
    platform: 'bank_transfer',
    transactionId: '',
    sentTo: '',
    paymentDate: new Date().toISOString().split('T')[0],
    notes: '',
  });

  useEffect(() => {
    setCart(getCart());
  }, []);

  useEffect(() => {
    if (!user) {
      toast.error('Please login to view your cart');
      navigate('/login');
    }
  }, [user, navigate]);

  const handleRemove = (productId: string) => {
    const updatedCart = removeFromCart(productId);
    setCart(updatedCart);
    toast.success('Item removed from cart');
  };

  const subtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const depositAmount = subtotal * 0.1;

  const handlePaymentSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (cart.length === 0) return;

    setLoading(true);
    try {
      // Create orders for each cart item
      for (const item of cart) {
        const { data: orderData, error: orderError } = await createOrder({
          product_id: item.product_id,
          buyer_id: user!.id,
          quantity: item.quantity,
          total_amount: item.price * item.quantity,
          deposit_amount: item.price * item.quantity * 0.1,
        });

        if (orderError) throw orderError;

        // Submit payment for this order
        if (orderData && orderData[0]) {
          const order = orderData[0] as { id: string };
          const { error: paymentError } = await submitPayment({
            order_id: order.id,
            amount: item.price * item.quantity * 0.1,
            payment_type: 'deposit',
            transaction_id: paymentData.transactionId,
            platform: paymentData.platform === 'bank_transfer' ? 'Bank Transfer' : 
                     paymentData.platform === 'mobile_money' ? 'Mobile Money' : 'Other',
            sent_to: paymentData.sentTo,
            payment_date: paymentData.paymentDate,
            notes: paymentData.notes,
          });

          if (paymentError) throw paymentError;
        }
      }

      clearCart();
      setCart([]);
      toast.success('Order placed successfully! Admin will verify your payment soon.');
      navigate('/buyer/dashboard');
    } catch (error: any) {
      console.error('Error placing order:', error);
      toast.error(error.message || 'Failed to place order');
    } finally {
      setLoading(false);
    }
  };

  if (!user) return null;

  return (
    <div className="pt-24 pb-16 bg-[#fafafa] min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <button
          onClick={() => navigate(-1)}
          className="flex items-center text-stone-600 hover:text-[#8b6d4b] mb-6"
        >
          <ArrowLeft className="w-5 h-5 mr-2" />
          Continue Shopping
        </button>

        <h1 className="text-3xl font-serif text-stone-900 mb-8">Shopping Cart</h1>

        {cart.length === 0 ? (
          <div className="text-center py-16 bg-white rounded-lg">
            <div className="w-20 h-20 bg-stone-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <svg className="w-10 h-10 text-stone-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
              </svg>
            </div>
            <h2 className="text-xl font-semibold mb-2">Your cart is empty</h2>
            <p className="text-stone-500 mb-6">Add some beautiful items to get started</p>
            <Button onClick={() => navigate('/')} className="bg-[#8b6d4b] hover:bg-[#6d5639]">
              Browse Products
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Cart Items */}
            <div className="lg:col-span-2 space-y-4">
              {cart.map((item) => (
                <Card key={item.product_id} className="overflow-hidden">
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-4">
                      <img
                        src={item.image_url}
                        alt={item.name}
                        className="w-24 h-24 object-cover rounded-lg"
                      />
                      <div className="flex-1">
                        <h3 className="font-semibold text-lg">{item.name}</h3>
                        <p className="text-[#8b6d4b] font-bold">${item.price}</p>
                        <p className="text-stone-500 text-sm">Quantity: {item.quantity}</p>
                      </div>
                      <div className="text-right">
                        <p className="font-bold text-lg">${(item.price * item.quantity).toFixed(2)}</p>
                        <button
                          onClick={() => handleRemove(item.product_id)}
                          className="text-red-500 hover:text-red-700 mt-2"
                        >
                          <Trash2 className="w-5 h-5" />
                        </button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Order Summary */}
            <div>
              <Card className="sticky top-24">
                <CardHeader>
                  <CardTitle>Order Summary</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-stone-600">Subtotal</span>
                      <span>${subtotal.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-[#8b6d4b]">
                      <span>Deposit Required (10%)</span>
                      <span className="font-bold">${depositAmount.toFixed(2)}</span>
                    </div>
                    <Separator />
                    <div className="flex justify-between text-lg font-bold">
                      <span>Pay Now</span>
                      <span>${depositAmount.toFixed(2)}</span>
                    </div>
                  </div>

                  {!showPaymentForm ? (
                    <Button
                      className="w-full mt-6 bg-[#8b6d4b] hover:bg-[#6d5639] text-white"
                      onClick={() => setShowPaymentForm(true)}
                    >
                      Proceed to Payment
                    </Button>
                  ) : (
                    <form onSubmit={handlePaymentSubmit} className="mt-6 space-y-4">
                      <div>
                        <Label className="mb-2 block">Payment Method</Label>
                        <RadioGroup
                          value={paymentData.platform}
                          onValueChange={(value) => setPaymentData({ ...paymentData, platform: value })}
                          className="space-y-2"
                        >
                          <div className="flex items-center space-x-2 border p-3 rounded-lg">
                            <RadioGroupItem value="bank_transfer" id="bank" />
                            <Label htmlFor="bank" className="flex items-center cursor-pointer">
                              <Building2 className="w-5 h-5 mr-2 text-[#8b6d4b]" />
                              Bank Transfer
                            </Label>
                          </div>
                          <div className="flex items-center space-x-2 border p-3 rounded-lg">
                            <RadioGroupItem value="mobile_money" id="mobile" />
                            <Label htmlFor="mobile" className="flex items-center cursor-pointer">
                              <Smartphone className="w-5 h-5 mr-2 text-[#8b6d4b]" />
                              Mobile Money
                            </Label>
                          </div>
                          <div className="flex items-center space-x-2 border p-3 rounded-lg">
                            <RadioGroupItem value="other" id="other" />
                            <Label htmlFor="other" className="flex items-center cursor-pointer">
                              <CreditCard className="w-5 h-5 mr-2 text-[#8b6d4b]" />
                              Other
                            </Label>
                          </div>
                        </RadioGroup>
                      </div>

                      <div>
                        <Label htmlFor="transactionId">Transaction ID / Reference Number</Label>
                        <Input
                          id="transactionId"
                          value={paymentData.transactionId}
                          onChange={(e) => setPaymentData({ ...paymentData, transactionId: e.target.value })}
                          placeholder="e.g., TXN123456"
                          required
                        />
                      </div>

                      <div>
                        <Label htmlFor="sentTo">Sent To (Account/Phone Number)</Label>
                        <Input
                          id="sentTo"
                          value={paymentData.sentTo}
                          onChange={(e) => setPaymentData({ ...paymentData, sentTo: e.target.value })}
                          placeholder="e.g., 1234567890"
                          required
                        />
                      </div>

                      <div>
                        <Label htmlFor="paymentDate">Payment Date</Label>
                        <Input
                          id="paymentDate"
                          type="date"
                          value={paymentData.paymentDate}
                          onChange={(e) => setPaymentData({ ...paymentData, paymentDate: e.target.value })}
                          required
                        />
                      </div>

                      <div>
                        <Label htmlFor="notes">Additional Notes (Optional)</Label>
                        <Input
                          id="notes"
                          value={paymentData.notes}
                          onChange={(e) => setPaymentData({ ...paymentData, notes: e.target.value })}
                          placeholder="Any additional details..."
                        />
                      </div>

                      <div className="flex space-x-2">
                        <Button
                          type="button"
                          variant="outline"
                          className="flex-1"
                          onClick={() => setShowPaymentForm(false)}
                        >
                          Cancel
                        </Button>
                        <Button
                          type="submit"
                          className="flex-1 bg-[#8b6d4b] hover:bg-[#6d5639] text-white"
                          disabled={loading}
                        >
                          {loading ? (
                            <>
                              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                              Processing...
                            </>
                          ) : (
                            'Confirm Payment'
                          )}
                        </Button>
                      </div>
                    </form>
                  )}

                  <p className="text-xs text-stone-500 mt-4 text-center">
                    You'll pay the remaining 90% on delivery
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
