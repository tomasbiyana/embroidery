import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Eye, EyeOff, Mail, Lock, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { signIn } from '../lib/supabase';
import { toast } from 'sonner';

export default function Login() {
  const navigate = useNavigate();
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [formData, setFormData] = useState({
    email: '',
    password: '',
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const { data, error } = await signIn(formData.email, formData.password);
      
      if (error) {
        setError(error.message);
        toast.error(error.message);
      } else if (data.user) {
        toast.success('Welcome back!');
        // Get user role from metadata and redirect accordingly
        const role = data.user.user_metadata?.role || 'buyer';
        switch (role) {
          case 'admin':
            navigate('/admin/dashboard');
            break;
          case 'seller':
            navigate('/seller/dashboard');
            break;
          default:
            navigate('/buyer/dashboard');
        }
      }
    } catch (err) {
      setError('An unexpected error occurred');
      toast.error('An unexpected error occurred');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#fafafa] py-12 px-4 sm:px-6 lg:px-8">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <CardTitle className="text-3xl font-serif text-[#8b6d4b]">Welcome Back</CardTitle>
          <CardDescription>Sign in to your Stitch & Style account</CardDescription>
        </CardHeader>
        
        <CardContent>
          {error && (
            <Alert variant="destructive" className="mb-4">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email Address</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-stone-400" />
                <Input
                  id="email"
                  type="email"
                  placeholder="you@example.com"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="pl-10"
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-stone-400" />
                <Input
                  id="password"
                  type={showPassword ? 'text' : 'password'}
                  placeholder="••••••••"
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  className="pl-10 pr-10"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-600"
                >
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between text-sm">
              <label className="flex items-center">
                <input type="checkbox" className="rounded border-stone-300 text-[#8b6d4b] focus:ring-[#8b6d4b]" />
                <span className="ml-2 text-stone-600">Remember me</span>
              </label>
              <Link to="/forgot-password" className="text-[#8b6d4b] hover:underline">
                Forgot password?
              </Link>
            </div>

            <Button
              type="submit"
              className="w-full bg-[#8b6d4b] hover:bg-[#6d5639] text-white"
              disabled={loading}
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Signing in...
                </>
              ) : (
                'Sign In'
              )}
            </Button>
          </form>

          <div className="mt-6 text-center">
            <p className="text-stone-600">
              Don't have an account?{' '}
              <Link to="/register" className="text-[#8b6d4b] hover:underline font-medium">
                Create one
              </Link>
            </p>
          </div>

          <div className="mt-6 pt-6 border-t border-stone-200">
            <p className="text-center text-sm text-stone-500 mb-4">Demo Accounts</p>
            <div className="grid grid-cols-3 gap-2 text-xs text-stone-500">
              <div className="bg-stone-100 p-2 rounded text-center">
                <p className="font-semibold">Admin</p>
                <p>admin@demo.com</p>
              </div>
              <div className="bg-stone-100 p-2 rounded text-center">
                <p className="font-semibold">Seller</p>
                <p>seller@demo.com</p>
              </div>
              <div className="bg-stone-100 p-2 rounded text-center">
                <p className="font-semibold">Buyer</p>
                <p>buyer@demo.com</p>
              </div>
            </div>
            <p className="text-center text-xs text-stone-400 mt-2">Password: password123</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
