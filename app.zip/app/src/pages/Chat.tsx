import { useEffect, useState, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Send, Loader2, User } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { getMessages, sendMessage, subscribeToMessages, supabase } from '../lib/supabase';
import { toast } from 'sonner';
import type { User as UserType } from '../App';

interface Message {
  id: string;
  order_id: string;
  sender_id: string;
  content: string;
  created_at: string;
  sender: {
    full_name: string;
    role: string;
  };
}

interface Order {
  id: string;
  product: {
    name: string;
    image_url: string;
  };
  buyer: {
    full_name: string;
  };
  seller?: {
    full_name: string;
  };
}

interface ChatProps {
  user: UserType | null;
}

export default function Chat({ user }: ChatProps) {
  const { orderId } = useParams<{ orderId: string }>();
  const navigate = useNavigate();
  const [messages, setMessages] = useState<Message[]>([]);
  const [order, setOrder] = useState<Order | null>(null);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (orderId && user) {
      loadOrder();
      loadMessages();
      
      // Subscribe to real-time messages
      const subscription = subscribeToMessages(orderId, (payload) => {
        setMessages((prev) => [...prev, payload.new]);
        scrollToBottom();
      });

      return () => {
        subscription.unsubscribe();
      };
    }
  }, [orderId, user]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const loadOrder = async () => {
    try {
      const { data, error } = await supabase
        .from('orders')
        .select(`
          *,
          product:products(name, image_url),
          buyer:profiles(full_name),
          seller:profiles!products(seller_id, full_name)
        `)
        .eq('id', orderId)
        .single();

      if (error) throw error;
      setOrder(data as Order);
    } catch (error) {
      console.error('Error loading order:', error);
    }
  };

  const loadMessages = async () => {
    try {
      const { data, error } = await getMessages(orderId || '');
      if (error) throw error;
      setMessages((data as Message[]) || []);
      setTimeout(scrollToBottom, 100);
    } catch (error) {
      console.error('Error loading messages:', error);
      toast.error('Failed to load messages');
    } finally {
      setLoading(false);
    }
  };

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim() || !user) return;

    setSending(true);
    try {
      const { error } = await sendMessage({
        order_id: orderId!,
        sender_id: user.id,
        content: newMessage.trim(),
      });

      if (error) throw error;
      setNewMessage('');
    } catch (error) {
      toast.error('Failed to send message');
    } finally {
      setSending(false);
    }
  };

  const isOwnMessage = (message: Message) => message.sender_id === user?.id;

  if (!user) {
    return (
      <div className="pt-24 text-center">
        <p>Please login to access chat</p>
        <Button onClick={() => navigate('/login')} className="mt-4">
          Login
        </Button>
      </div>
    );
  }

  return (
    <div className="pt-20 pb-4 bg-[#fafafa] min-h-screen">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 h-[calc(100vh-6rem)]">
        <Card className="h-full flex flex-col">
          {/* Header */}
          <CardHeader className="border-b flex-shrink-0">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <button
                  onClick={() => navigate(-1)}
                  className="p-2 hover:bg-stone-100 rounded-full"
                >
                  <ArrowLeft className="w-5 h-5" />
                </button>
                {order && (
                  <div className="flex items-center space-x-3">
                    <img
                      src={order.product?.image_url}
                      alt={order.product?.name}
                      className="w-10 h-10 object-cover rounded-lg"
                    />
                    <div>
                      <CardTitle className="text-lg">{order.product?.name}</CardTitle>
                      <p className="text-sm text-stone-500">
                        Buyer: {order.buyer?.full_name}
                      </p>
                    </div>
                  </div>
                )}
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-500 rounded-full" />
                <span className="text-sm text-stone-500">Online</span>
              </div>
            </div>
          </CardHeader>

          {/* Messages */}
          <CardContent className="flex-1 overflow-y-auto p-4">
            {loading ? (
              <div className="flex justify-center items-center h-full">
                <Loader2 className="w-8 h-8 animate-spin text-[#8b6d4b]" />
              </div>
            ) : messages.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full text-stone-400">
                <div className="w-16 h-16 bg-stone-100 rounded-full flex items-center justify-center mb-4">
                  <Send className="w-8 h-8" />
                </div>
                <p>No messages yet</p>
                <p className="text-sm">Start the conversation!</p>
              </div>
            ) : (
              <div className="space-y-4">
                {messages.map((message, index) => {
                  const own = isOwnMessage(message);
                  const showAvatar = index === 0 || messages[index - 1].sender_id !== message.sender_id;

                  return (
                    <div
                      key={message.id}
                      className={`flex ${own ? 'justify-end' : 'justify-start'}`}
                    >
                      <div className={`flex max-w-[80%] ${own ? 'flex-row-reverse' : 'flex-row'}`}>
                        {showAvatar && (
                          <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                            message.sender.role === 'admin' ? 'bg-purple-100 text-purple-600' :
                            message.sender.role === 'seller' ? 'bg-blue-100 text-blue-600' :
                            'bg-green-100 text-green-600'
                          } ${own ? 'ml-2' : 'mr-2'}`}>
                            <User className="w-4 h-4" />
                          </div>
                        )}
                        {!showAvatar && <div className="w-8 mr-2" />}
                        
                        <div>
                          {showAvatar && (
                            <p className={`text-xs text-stone-500 mb-1 ${own ? 'text-right' : 'text-left'}`}>
                              {message.sender.full_name}
                              {message.sender.role === 'admin' && (
                                <span className="ml-1 text-purple-600">(Admin)</span>
                              )}
                            </p>
                          )}
                          <div
                            className={`px-4 py-2 rounded-2xl ${
                              own
                                ? 'bg-[#8b6d4b] text-white rounded-br-none'
                                : 'bg-stone-100 text-stone-800 rounded-bl-none'
                            }`}
                          >
                            <p>{message.content}</p>
                          </div>
                          <p className={`text-xs text-stone-400 mt-1 ${own ? 'text-right' : 'text-left'}`}>
                            {new Date(message.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </p>
                        </div>
                      </div>
                    </div>
                  );
                })}
                <div ref={messagesEndRef} />
              </div>
            )}
          </CardContent>

          {/* Input */}
          <CardContent className="border-t p-4 flex-shrink-0">
            <form onSubmit={handleSend} className="flex space-x-2">
              <Input
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                placeholder="Type your message..."
                className="flex-1"
                disabled={sending}
              />
              <Button
                type="submit"
                className="bg-[#8b6d4b] hover:bg-[#6d5639]"
                disabled={sending || !newMessage.trim()}
              >
                {sending ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Send className="w-4 h-4" />
                )}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
