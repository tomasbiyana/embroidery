import { createClient } from '@supabase/supabase-js';

// These will be replaced with your actual Supabase credentials
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://ebfzdumksqtexerlntzi.supabase.co';
const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImViZnpkdW1rc3F0ZXhlcmxudHppIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzM2NDE5MTYsImV4cCI6MjA4OTIxNzkxNn0.U9_7x6qUyPcQSZPRwFDnt4nTorATNU4_OBaQcbndlTs';

export const supabase = createClient(supabaseUrl, supabaseKey);

// Auth helpers
export const signUp = async (email: string, password: string, userData: { full_name: string; phone: string; role: 'buyer' | 'seller' | 'admin' }) => {
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: {
      data: userData,
    },
  });
  return { data, error };
};

export const signIn = async (email: string, password: string) => {
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password,
  });
  return { data, error };
};

export const signOut = async () => {
  const { error } = await supabase.auth.signOut();
  return { error };
};

export const getCurrentUser = async () => {
  const { data: { user }, error } = await supabase.auth.getUser();
  if (error || !user) return null;
  
  const { data: profile } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', user.id)
    .single();
    
  return profile;
};

// Product helpers
export const getProducts = async (status?: string) => {
  let query = supabase.from('products').select('*, seller:profiles(full_name, phone)');
  if (status) query = query.eq('status', status);
  const { data, error } = await query.order('created_at', { ascending: false });
  return { data, error };
};

export const getProductById = async (id: string) => {
  const { data, error } = await supabase
    .from('products')
    .select('*, seller:profiles(full_name, phone)')
    .eq('id', id)
    .single();
  return { data, error };
};

export const createProduct = async (product: {
  name: string;
  description: string;
  price: number;
  image_url: string;
  completion_days: number;
  category: string;
  seller_id: string;
}) => {
  const { data, error } = await supabase.from('products').insert(product).select();
  return { data, error };
};

// Order helpers
export const createOrder = async (order: {
  product_id: string;
  buyer_id: string;
  quantity: number;
  total_amount: number;
  deposit_amount: number;
}) => {
  const { data, error } = await supabase.from('orders').insert(order).select();
  return { data, error };
};

export const getOrders = async (userId?: string, role?: string) => {
  let query = supabase
    .from('orders')
    .select('*, product:products(*), buyer:profiles!orders_buyer_id_fkey(*), seller:profiles!products(seller_id)') as any;
    
  if (userId && role === 'buyer') query = query.eq('buyer_id', userId);
  if (userId && role === 'seller') {
    query = query.eq('product.seller_id', userId);
  }
  
  const { data, error } = await query.order('created_at', { ascending: false });
  return { data, error };
};

export const updateOrderStatus = async (orderId: string, status: string) => {
  const { data, error } = await supabase
    .from('orders')
    .update({ status })
    .eq('id', orderId)
    .select();
  return { data, error };
};

// Payment helpers
export const submitPayment = async (payment: {
  order_id: string;
  amount: number;
  payment_type: 'deposit' | 'final';
  transaction_id: string;
  platform: string;
  sent_to: string;
  payment_date: string;
  notes?: string;
}) => {
  const { data, error } = await supabase.from('payments').insert(payment).select();
  return { data, error };
};

export const verifyPayment = async (paymentId: string, verified: boolean) => {
  const { data, error } = await supabase
    .from('payments')
    .update({ verified, verified_at: verified ? new Date().toISOString() : null })
    .eq('id', paymentId)
    .select();
  return { data, error };
};

// Chat helpers
export const getMessages = async (orderId: string) => {
  const { data, error } = await supabase
    .from('messages')
    .select('*, sender:profiles(full_name, role)')
    .eq('order_id', orderId)
    .order('created_at', { ascending: true });
  return { data, error };
};

export const sendMessage = async (message: {
  order_id: string;
  sender_id: string;
  content: string;
}) => {
  const { data, error } = await supabase.from('messages').insert(message).select();
  return { data, error };
};

// Subscribe to messages for real-time chat
export const subscribeToMessages = (orderId: string, callback: (payload: any) => void) => {
  return supabase
    .channel(`messages:${orderId}`)
    .on('postgres_changes', 
      { event: 'INSERT', schema: 'public', table: 'messages', filter: `order_id=eq.${orderId}` },
      callback
    )
    .subscribe();
};

// Cart helpers (using localStorage for simplicity)
export const getCart = () => {
  const cart = localStorage.getItem('embroidery_cart');
  return cart ? JSON.parse(cart) : [];
};

export const addToCart = (item: any) => {
  const cart = getCart();
  const existing = cart.find((i: any) => i.product_id === item.product_id);
  if (existing) {
    existing.quantity += item.quantity;
  } else {
    cart.push(item);
  }
  localStorage.setItem('embroidery_cart', JSON.stringify(cart));
  return cart;
};

export const removeFromCart = (productId: string) => {
  const cart = getCart().filter((i: any) => i.product_id !== productId);
  localStorage.setItem('embroidery_cart', JSON.stringify(cart));
  return cart;
};

export const clearCart = () => {
  localStorage.removeItem('embroidery_cart');
};
