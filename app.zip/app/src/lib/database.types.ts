export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string
          email: string
          full_name: string
          phone: string
          role: 'admin' | 'seller' | 'buyer'
          avatar_url: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id: string
          email: string
          full_name: string
          phone: string
          role?: 'admin' | 'seller' | 'buyer'
          avatar_url?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          email?: string
          full_name?: string
          phone?: string
          role?: 'admin' | 'seller' | 'buyer'
          avatar_url?: string | null
          created_at?: string
          updated_at?: string
        }
      }
      products: {
        Row: {
          id: string
          seller_id: string
          name: string
          description: string
          price: number
          image_url: string
          completion_days: number
          category: string
          status: 'pending' | 'approved' | 'rejected' | 'sold'
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          seller_id: string
          name: string
          description: string
          price: number
          image_url: string
          completion_days: number
          category: string
          status?: 'pending' | 'approved' | 'rejected' | 'sold'
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          seller_id?: string
          name?: string
          description?: string
          price?: number
          image_url?: string
          completion_days?: number
          category?: string
          status?: 'pending' | 'approved' | 'rejected' | 'sold'
          created_at?: string
          updated_at?: string
        }
      }
      orders: {
        Row: {
          id: string
          product_id: string
          buyer_id: string
          quantity: number
          total_amount: number
          deposit_amount: number
          status: 'pending_deposit' | 'deposit_paid' | 'deposit_verified' | 'in_production' | 'ready_for_delivery' | 'final_payment_pending' | 'completed' | 'cancelled'
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          product_id: string
          buyer_id: string
          quantity: number
          total_amount: number
          deposit_amount: number
          status?: 'pending_deposit' | 'deposit_paid' | 'deposit_verified' | 'in_production' | 'ready_for_delivery' | 'final_payment_pending' | 'completed' | 'cancelled'
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          product_id?: string
          buyer_id?: string
          quantity?: number
          total_amount?: number
          deposit_amount?: number
          status?: 'pending_deposit' | 'deposit_paid' | 'deposit_verified' | 'in_production' | 'ready_for_delivery' | 'final_payment_pending' | 'completed' | 'cancelled'
          created_at?: string
          updated_at?: string
        }
      }
      payments: {
        Row: {
          id: string
          order_id: string
          amount: number
          payment_type: 'deposit' | 'final'
          transaction_id: string
          platform: string
          sent_to: string
          payment_date: string
          notes: string | null
          verified: boolean
          verified_at: string | null
          created_at: string
        }
        Insert: {
          id?: string
          order_id: string
          amount: number
          payment_type: 'deposit' | 'final'
          transaction_id: string
          platform: string
          sent_to: string
          payment_date: string
          notes?: string | null
          verified?: boolean
          verified_at?: string | null
          created_at?: string
        }
        Update: {
          id?: string
          order_id?: string
          amount?: number
          payment_type?: 'deposit' | 'final'
          transaction_id?: string
          platform?: string
          sent_to?: string
          payment_date?: string
          notes?: string | null
          verified?: boolean
          verified_at?: string | null
          created_at?: string
        }
      }
      messages: {
        Row: {
          id: string
          order_id: string
          sender_id: string
          content: string
          created_at: string
          read: boolean
        }
        Insert: {
          id?: string
          order_id: string
          sender_id: string
          content: string
          created_at?: string
          read?: boolean
        }
        Update: {
          id?: string
          order_id?: string
          sender_id?: string
          content?: string
          created_at?: string
          read?: boolean
        }
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
  }
}
