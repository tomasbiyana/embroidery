# Embroidery Marketplace - Setup Guide

## 🚀 Quick Start

This guide will help you set up the Embroidery Marketplace with Supabase (free tier) and deploy it on Netlify (free tier).

---

## 📋 Prerequisites

1. **Supabase Account** (Free) - [https://supabase.com](https://supabase.com)
2. **Netlify Account** (Free) - [https://netlify.com](https://netlify.com)
3. **GitHub Account** (Optional, for easier deployment)

---

## 🔧 Step 1: Set Up Supabase Database

### 1.1 Create a Supabase Project

1. Go to [https://app.supabase.com](https://app.supabase.com)
2. Click "New Project"
3. Enter:
   - **Name**: `embroidery-marketplace`
   - **Database Password**: Create a strong password (save it!)
   - **Region**: Choose closest to your users
4. Click "Create new project"
5. Wait for the project to be created (2-3 minutes)

### 1.2 Get Your API Credentials

1. In your Supabase dashboard, go to **Project Settings** → **API**
2. Copy these values (you'll need them later):
   - **Project URL** (e.g., `https://abcdefgh12345678.supabase.co`)
   - **anon/public** API key (starts with `eyJ...`)

### 1.3 Create Database Tables

1. In Supabase dashboard, go to **SQL Editor**
2. Click "New query"
3. Copy and paste the entire contents of `supabase-schema.sql` file from this project
4. Click "Run" to execute all the SQL commands

This will create:
- `profiles` table (user information)
- `products` table (seller items)
- `orders` table (buyer orders)
- `payments` table (payment records)
- `messages` table (chat messages)
- All necessary indexes and security policies (RLS)

### 1.4 Set Up Authentication

1. Go to **Authentication** → **Providers**
2. Ensure "Email" provider is enabled (it is by default)
3. (Optional) Configure email templates in **Authentication** → **Email Templates**

### 1.5 Create Admin User

1. Go to **Authentication** → **Users**
2. Click "Add user" → "Create new user"
3. Enter:
   - Email: `admin@yourdomain.com`
   - Password: (create a strong password)
4. Click "Create user"
5. After creation, go to **Table Editor** → **profiles**
6. Find the new user and change `role` from `buyer` to `admin`

---

## 💻 Step 2: Configure the Application

### 2.1 Update Environment Variables

1. Open the file `src/lib/supabase.ts`
2. Replace the placeholder values:

```typescript
const supabaseUrl = 'https://your-project-url.supabase.co';
const supabaseKey = 'your-anon-key';
```

With your actual values from Step 1.2.

### 2.2 Alternative: Use Environment Variables (Recommended for Production)

Create a `.env` file in the project root:

```env
VITE_SUPABASE_URL=https://your-project-url.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-key
```

Then update `src/lib/supabase.ts`:

```typescript
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
```

---

## 🏗️ Step 3: Build the Application

### 3.1 Install Dependencies

```bash
npm install
```

### 3.2 Build for Production

```bash
npm run build
```

This creates a `dist/` folder with all the built files.

---

## 🌐 Step 4: Deploy to Netlify

### Option A: Drag & Drop (Easiest)

1. Go to [https://app.netlify.com](https://app.netlify.com)
2. Drag and drop the `dist/` folder onto the Netlify dashboard
3. Your site will be live instantly!

### Option B: Connect to Git (Recommended for updates)

1. Push your code to GitHub
2. In Netlify, click "Add new site" → "Import an existing project"
3. Connect to your GitHub repository
4. Configure build settings:
   - **Build command**: `npm run build`
   - **Publish directory**: `dist`
5. Add environment variables (if using `.env`):
   - Go to **Site settings** → **Environment variables**
   - Add `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY`
6. Click "Deploy site"

---

## 📱 Social Media Links

Update the social media links in `src/components/Footer.tsx`:

```typescript
const socialLinks = [
  { icon: Instagram, label: 'Instagram', href: 'https://instagram.com/yourhandle' },
  { icon: Facebook, label: 'Facebook', href: 'https://facebook.com/yourpage' },
  { icon: Twitter, label: 'Twitter', href: 'https://twitter.com/yourhandle' },
  { icon: MessageCircle, label: 'WhatsApp', href: 'https://wa.me/yourphonenumber' },
];
```

Also update contact information in the same file.

---

## 👥 User Roles

### Admin
- Manages all products, orders, and payments
- Verifies payments (deposit and final)
- Communicates with buyers and sellers via chat
- Can approve/reject seller products

### Seller
- Posts products with images (URL), price, and completion time
- Views orders for their products
- Communicates with admin via chat
- Marks orders as ready for delivery

### Buyer
- Browses approved products
- Adds items to cart
- Pays 10% deposit to place order
- Tracks order status
- Communicates with admin via chat
- Pays 90% balance on delivery

---

## 💳 Payment Flow

1. **Buyer** adds items to cart
2. **Buyer** pays 10% deposit via bank/mobile transfer
3. **Buyer** submits payment details (transaction ID, platform, date)
4. **Admin** verifies the payment in dashboard
5. **Seller** sees the verified order and starts production
6. **Seller** marks order as "ready for delivery"
7. **Admin** notifies buyer to pay 90% balance
8. **Buyer** pays remaining amount
9. **Admin** verifies final payment
10. **Order** marked as completed

---

## 🔐 Security Notes

- Row Level Security (RLS) is enabled on all tables
- Users can only access their own data
- Admin has full access to all data
- All passwords are hashed by Supabase Auth
- File uploads should use Supabase Storage (not implemented in this version)

---

## 🐛 Troubleshooting

### "Failed to fetch" error
- Check your Supabase URL is correct
- Ensure your Supabase project is active

### "Permission denied" error
- Check RLS policies are set up correctly
- Run the SQL schema again if needed

### "User not found" error
- Ensure the user exists in both `auth.users` and `profiles` tables
- The trigger should auto-create profile entries

---

## 📞 Support

For issues or questions:
1. Check Supabase documentation: [https://supabase.com/docs](https://supabase.com/docs)
2. Check Netlify documentation: [https://docs.netlify.com](https://docs.netlify.com)
3. Review the SQL schema in `supabase-schema.sql`

---

## 📝 License

This project is open source. Feel free to modify and use as needed.

---

**Happy Selling! 🎉**
